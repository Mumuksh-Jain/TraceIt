# Trace It — Node/Express Backend Documentation

## Introduction for Beginners
The Node backend is the **"brain"** of Trace It. It sits between the React frontend and the rest of the system — handling user requests, talking to MongoDB, and calling the Python AI service when a match is needed.

The backend's job is to:
* Receive HTTP requests from the React frontend (login, register, fetch lost items, etc.)
* Verify the user is who they say they are (authentication via JWT cookies)
* Read and write data to MongoDB Atlas (lost items, found items, users)
* Call the Python AI service when a user requests semantic matching
* Send a clean JSON response back to the frontend

This project is built using:
* **Express** — A minimal web framework for Node.js. Handles routing (which URL maps to which function).
* **Mongoose** — An ODM (Object Data Mapper) that lets us define schemas and talk to MongoDB with clean JavaScript code.
* **JWT (jsonwebtoken)** — Creates and verifies secure tokens used to keep users logged in.
* **bcrypt** — Hashes passwords before storing them. Never stores plain text passwords.
* **cookie-parser** — Reads HTTP cookies from incoming requests (where the JWT token lives).
* **CORS** — Controls which frontend origins are allowed to talk to this backend.
* **axios** — Used server-side to call the Python AI matching service.
* **dotenv** — Loads environment variables from the `.env` file.

---

## Project Directory Structure

```text
backend-node/
├── package.json                  # Lists all npm packages and scripts
├── server.js                     # Entry point. Starts the Express server on PORT
├── .env                          # Secret config (never committed to Git)
├── .dockerignore                 # Stops node_modules and .env going into Docker image
├── Dockerfile                    # Instructions to build the Node Docker image
├── src/
│   ├── app.js                    # Creates the Express app, registers middleware and routes
│   ├── db/
│   │   └── db.js                 # Connects to MongoDB Atlas using MONGODB_URI
│   ├── models/
│   │   ├── user.model.js         # Mongoose schema for users (username, email, password hash)
│   │   ├── lostItem.model.js     # Mongoose schema for lost items (description, location, etc.)
│   │   └── foundItem.model.js    # Mongoose schema for found items
│   ├── controllers/
│   │   ├── auth.controller.js    # Register, login, logout, checkAuth logic
│   │   ├── lostItem.controller.js  # CRUD for lost items + AI match trigger
│   │   └── foundItem.controller.js # CRUD for found items
│   ├── routes/
│   │   ├── auth.route.js         # /api/auth/* → auth controller
│   │   ├── lostitem.route.js     # /api/lost/* → lost item controller
│   │   └── foundItem.route.js    # /api/found/* → found item controller
│   ├── middlewares/
│   │   └── auth.middleware.js    # protectRoute — checks JWT cookie before private routes
│   └── services/
│       └── api.js                # Axios instance configured to call Python AI service
```

---

## Environment Variables

```env
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/TraceIt   # Atlas connection string
PYTHON_API_URL=http://python-ai:5000                              # Python service URL (service name in Docker)
JWT_SECRET_KEY=your_secret_key                                    # Signs and verifies JWT tokens
PORT=3000                                                         # Express listen port
```

> **Important:** `PYTHON_API_URL` uses `http://python-ai:5000` inside Docker (service name on the shared network), and `http://localhost:5000` when running locally without Docker.

---

## How It All Connects (The Request Journey)

Here is a step-by-step example of what happens when a user submits a lost item and requests AI matching:

1. **Request arrives** — React sends `POST /api/lost` with item description in the body.
2. **Middleware check (`auth.middleware.js`)** — `protectRoute` reads the JWT cookie from the request, verifies it using `JWT_SECRET_KEY`. If invalid or missing → 401 Unauthorized. If valid → attaches `req.user` and continues.
3. **Controller runs (`lostItem.controller.js`)** — Saves the new lost item to MongoDB via the `lostItemModel`.
4. **AI match triggered** — When the user requests `/api/lost/match/:id`, the controller fetches the lost item's description and all found item descriptions from MongoDB, then POSTs them to `PYTHON_API_URL/match` via axios.
5. **Python responds** — The Python AI service returns a ranked list of matches with similarity scores.
6. **Response sent** — The controller sends the ranked matches back to React as JSON.

---

## Detailed File Concepts

### 1. Entry Point (`server.js`)
* Imports the Express app from `app.js` and the database connector from `db.js`.
* Calls `connectDb()` to establish MongoDB connection.
* Calls `app.listen(PORT)` to start accepting requests.
* This is the only file Docker's CMD runs: `CMD ["node", "server.js"]`.

### 2. App Setup (`app.js`)
* Creates the Express app instance.
* Registers global middleware in order: CORS → express.json() → cookie-parser.
* Mounts route files at their base paths:
  * `/api/auth` → `auth.route.js`
  * `/api/lost` → `lostitem.route.js`
  * `/api/found` → `foundItem.route.js`
* CORS is configured to allow `http://localhost:5173` (dev) and `http://localhost:3001` (Docker).

### 3. Authentication Flow (`auth.controller.js`)
* **Register** — Checks if user exists → hashes password with bcrypt → saves user → signs JWT → sets `httpOnly` cookie.
* **Login** — Finds user by email/username → compares password with bcrypt → signs JWT → sets `httpOnly` cookie.
* **Logout** — Clears the token cookie.
* **CheckAuth** — Used by React on every page load to verify the session is still valid. Protected by `protectRoute` middleware.

### 4. Auth Middleware (`auth.middleware.js`)
* Reads `req.cookies.token`.
* Verifies it using `jwt.verify(token, JWT_SECRET_KEY)`.
* If valid, attaches the decoded payload to `req.user` and calls `next()`.
* If invalid or missing, returns 401 immediately.
* Applied to any route that requires the user to be logged in.

### 5. AI Matching (`lostItem.controller.js → matchItem`)
* Fetches the target lost item by ID from MongoDB.
* Fetches all found items from MongoDB.
* Sends both to Python AI via: `axios.post(PYTHON_API_URL + '/match', { lost, found })`.
* Python returns ranked scores → controller returns them to the frontend.

### 6. Database Connection (`db/db.js`)
* Calls `mongoose.connect(process.env.MONGODB_URI)`.
* Logs success or failure.
* Called once at startup from `server.js`.
* Uses MongoDB Atlas — no local MongoDB container needed.

---

## API Routes Reference

| Method | Route | Auth Required | Description |
|--------|-------|--------------|-------------|
| POST | /api/auth/register | No | Create new account |
| POST | /api/auth/login | No | Login, receive cookie |
| POST | /api/auth/logout | Yes | Clear auth cookie |
| GET | /api/auth/me | Yes | Get current user |
| GET | /api/lost | Yes | Get all lost items |
| POST | /api/lost | Yes | Create lost item |
| GET | /api/lost/match/:id | Yes | Run AI match for item |
| GET | /api/found | Yes | Get all found items |
| POST | /api/found | Yes | Create found item |

---

## Docker Setup

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["node", "server.js"]
```

**Key decisions:**
* `node:20-alpine` — 180MB vs 1GB for full Node image.
* `--only=production` — Skips devDependencies (nodemon, jest, etc.) in the final image.
* `package*.json` copied before source code — npm ci layer is cached unless dependencies change.
* `.env` never copied — injected at runtime via `docker compose env_file`.

**Run locally:**
```bash
docker build -t traceit-node .
docker run --rm -p 3000:3000 --env-file .env traceit-node
```

**Run via Compose:**
```bash
docker compose up -d
```
