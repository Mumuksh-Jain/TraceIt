# Trace It — Python AI Service Documentation

## Introduction for Beginners
The Python service is the **"AI brain"** of Trace It. It has one job — take a description of a lost item and a list of found item descriptions, and figure out which found items are most similar to the lost item using semantic AI matching.

This is not a simple keyword search. It understands *meaning*. If someone lost a "black leather wallet" and a found item says "dark coloured bifold", the AI will score that as a high match — even though no words overlap.

The service's job is to:
* Receive a POST request from the Node backend with a lost item description and a list of found item descriptions
* Convert all descriptions into mathematical vectors (embeddings) using a pre-trained AI model
* Calculate the cosine similarity between the lost item and every found item
* Return a ranked list of found items sorted by similarity score

This project is built using:
* **Flask** — A lightweight Python web framework. Handles the HTTP server and routing.
* **sentence-transformers** — A library that loads pre-trained AI models capable of converting text into high-dimensional vectors that capture semantic meaning.
* **PyTorch (CPU)** — The underlying ML engine that powers sentence-transformers. We use the CPU-only version to keep the image size manageable.
* **SentenceTransformer model: `all-MiniLM-L6-v2`** — A small but powerful model (~80MB) trained on hundreds of millions of sentence pairs. Fast, accurate, and ideal for semantic similarity tasks.

---

## Project Directory Structure

```text
backend-python/
├── app.py                  # The entire Flask application — one file, one route
├── requirements.txt        # Python package dependencies
├── .dockerignore           # Stops .env, __pycache__, .venv going into Docker image
└── Dockerfile              # Instructions to build the Python Docker image
```

---

## How It Works — The AI Matching Pipeline

When the Node backend calls `/match`, here is exactly what happens inside Python:

```
Node sends:
{
  "lost": "black leather wallet",
  "found": ["brown bag", "dark bifold wallet", "set of keys"]
}

Step 1 — Encode lost item:
  model.encode("black leather wallet") → [0.23, -0.41, 0.87, ...] (384 numbers)

Step 2 — Encode all found items:
  model.encode(["brown bag", ...]) → matrix of vectors

Step 3 — Cosine similarity:
  cos_sim(lost_vector, found_matrix) → [0.21, 0.85, 0.18]

Step 4 — Sort by score, return:
{
  "matches": [
    {"index": 1, "score": 0.85, "description": "dark bifold wallet"},
    {"index": 0, "score": 0.21, "description": "brown bag"},
    {"index": 2, "score": 0.18, "description": "set of keys"}
  ]
}
```

---

## Detailed File Concepts

### 1. The Flask App (`app.py`)

The entire service is one file with one route:

```python
@app.route('/match', methods=['POST'])
def match():
    data = request.json
    lost_description = data.get('lost')
    found_descriptions = data.get('found')
    ...
```

**Why one file?** This service has a single responsibility — match items. No auth, no database, no complex routing needed. Keeping it minimal makes it fast and easy to maintain.

### 2. The AI Model — `all-MiniLM-L6-v2`

This model is the core of the service. Key facts:

| Property | Value |
|----------|-------|
| Model size | ~80MB |
| Embedding dimensions | 384 |
| Language | English (multilingual variants exist) |
| Speed | ~1000 sentences/second on CPU |
| Use case | Semantic similarity, sentence embeddings |

**What is an embedding?** A list of 384 numbers that represents the *meaning* of a sentence. Sentences with similar meanings will have vectors that point in similar directions in 384-dimensional space. Cosine similarity measures the angle between two vectors — 1.0 = identical meaning, 0.0 = completely unrelated.

### 3. Model Loading Strategy

```python
# This runs ONCE when the app starts — not on every request
model = SentenceTransformer('all-MiniLM-L6-v2')
```

Loading the model takes ~2-3 seconds and uses ~200MB of RAM. By loading it at startup (module level), every request after that is fast — encoding 100 descriptions takes under 1 second.

**In Docker**, the model is also baked into the image at build time:
```dockerfile
RUN python -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('all-MiniLM-L6-v2')"
```
This means the container never downloads the model at runtime — it starts instantly.

### 4. Cosine Similarity

```python
scores = util.cos_sim(lost_embedding, found_embeddings)[0]
```

`cos_sim` returns a matrix. Since we have one lost item vs many found items, we take `[0]` — the first (and only) row — giving us a score for each found item.

Scores range from -1 to 1:
* **0.8 - 1.0** → Very strong semantic match
* **0.5 - 0.8** → Moderate match, worth reviewing
* **0.0 - 0.5** → Weak match, probably different items
* **< 0.0** → Opposite meaning (rare in practice)

### 5. Why Flask and not FastAPI?

Flask was chosen for simplicity. This service has one endpoint, no database, no complex middleware. Flask's minimal footprint keeps the codebase easy to understand. FastAPI would be a valid choice if the service grows (adds async, multiple routes, auto-generated docs).

---

## API Reference

### POST /match

**Request body:**
```json
{
  "lost": "black leather wallet with cards",
  "found": [
    "brown paper bag",
    "dark bifold wallet",
    "keys on a ring",
    "black purse"
  ]
}
```

**Response:**
```json
{
  "matches": [
    { "index": 1, "score": 0.847, "description": "dark bifold wallet" },
    { "index": 3, "score": 0.621, "description": "black purse" },
    { "index": 2, "score": 0.183, "description": "keys on a ring" },
    { "index": 0, "score": 0.142, "description": "brown paper bag" }
  ]
}
```

**Error (missing data):**
```json
{ "error": "Missing data" }   // HTTP 400
```

---

## Requirements

```
flask
sentence-transformers
torch  --index-url https://download.pytorch.org/whl/cpu
```

> We use CPU-only PyTorch (`+cpu`) — reduces download from 915MB to 188MB. Trace It runs on a standard server without a GPU, so CUDA libraries would be wasted space.

---

## Docker Setup

```dockerfile
FROM python:3.12-slim

WORKDIR /app

# Install gcc — needed to compile C extensions during pip install
RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Cache pip install layer — only re-runs if requirements.txt changes
COPY requirements.txt .
RUN pip install --no-cache-dir torch --index-url https://download.pytorch.org/whl/cpu && \
    pip install --no-cache-dir -r requirements.txt

# Bake the AI model into the image — never downloaded at runtime
RUN python -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('all-MiniLM-L6-v2')"

COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

**Key decisions:**
* `python:3.12-slim` — Stripped Debian base. ~130MB vs 1GB for the full image.
* `gcc` installed before pip — sentence-transformers compiles C extensions during install. Without gcc the build crashes.
* `--no-cache-dir` — Skips pip's download cache inside the image. Saves ~50MB.
* CPU-only torch — No CUDA/nvidia libraries. Image goes from ~4GB to ~1GB.
* Model baked in — Container starts in under 3 seconds instead of downloading 80MB on every boot.

**Final image size:** ~1GB (dominated by PyTorch even in CPU-only mode)

**Run locally:**
```bash
docker build -t traceit-python .
docker run --rm -p 5000:5000 traceit-python
```

**Test:**
```bash
curl -X POST http://localhost:5000/match \
  -H "Content-Type: application/json" \
  -d '{"lost": "black wallet", "found": ["brown bag", "black leather wallet", "keys"]}'
```

**Run via Compose:**
```bash
docker compose up -d
```

> The Python service is only accessible to the Node backend inside Docker — it is not intended to be called directly from the browser or frontend.
